  import 'package:google_place/google_place.dart';

var googlePlace = GooglePlace("AIzaSyCXEykmj3RsEDFNBrLCmA-lmxKCWqT-zCI");
