part of 'widgets.dart';

class AppBarSearchWidget extends StatelessWidget {
  const AppBarSearchWidget({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}