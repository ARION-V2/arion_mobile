package com.example.arion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
